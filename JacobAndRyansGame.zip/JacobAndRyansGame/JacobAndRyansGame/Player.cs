﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JacobAndRyansGame
{
    class Player
    {
        public Player()
        {
            Position = new int[] { 0, 0 };
        }
        public int[] Position { get; set; }
    }
}
