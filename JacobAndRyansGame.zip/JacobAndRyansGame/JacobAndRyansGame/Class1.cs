﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JacobAndRyansGame
{
    class Game
    {
        List<Monster> monsterList;
        Player player;
        int[,] gridArray = { { 0, 1, 2, 3, 4 },
                             { 0, 1, 2, 3, 4 },
                             { 0, 1, 2, 3, 4 },
                             { 0, 1, 2, 3, 4 },
                             { 0, 1, 2, 3, 4 }, };
        public void MovePlayer()
        {

        }
        public void UpdateMonsters()
        {
            foreach(Monster mon in monsterList)
            {
                mon.MoveMonster(player.Position);
            }
        }
    }
}
