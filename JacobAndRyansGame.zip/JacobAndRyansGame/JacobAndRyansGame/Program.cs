﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JacobAndRyansGame
{
    class Program
    {
        /*
        needs a player
        needds at least 2 enemies
        needs at least 2 Powerups
        needs a grid with keyboad movement
        */
        static void Main(string[] args)
        {
            Entity player = new Entity();
            Entity monster = new Entity();
            player.AddComponent(new KeyBoardMovement());
            monster.AddComponent(new killPLayerComponent(player));
            monster.AddComponent(new AIMovementComponent);
            player.AddComponent(new powerUpConponent()); //makes it so you can give a powerup to a player for a short time and then remove it
            while (true)
            {
                System.Console.WriteLine(player.Position);
                player.Update();
            }
        }
    }
    class KeepInBoundsComponent : Component
    {
        int bounds;
        public KeepInBoundsComponent(int bounds)
        {
            this.bounds = bounds;  
        }
        public override void Update()
        {
            if (Container.Position.X > bounds)
                Container.Position.X = bounds;

        }
        public int MaxX { get; set; }
        public int MaxY { get; set; }

    }

    class KillPlayerComponent : Component
    {
        Entity player;
        public KillPlayerComponent(Entity player)
        {
            this.player = player
        }
        public override void Update()
        {
            if(player.Position.X == Container.Position.X && player.Position.Y == Container.Position.Y)
            {

            }
        }
    }

    class Entity
    {
        public Entity()
        {
            Position = new Point();
        }
        List<Component> components = new List<Component>();
        public void AddComponent(Component addedComponent)
        {
            components.Add(addedComponent);
            addedComponent.Container = this;
        }
        public void Update()
        {

        }
        public Point Position { get; set; }
    }
    class Component
    {
        public virtual void Update() { }
        public Entity Container { get; set; }
    }
    class KeyBoardMovement : Component
    {
        public override void Update()
        {
            Console.WriteLine("Which way do you want to move it? (WASD)");
            char choice = Console.ReadKey().KeyChar;
            switch (choice)
            {
                case 'w':
                    Container.Position.Y--;
                    break;
                case 'a':
                    Container.Position.X--;
                    break;
                case 's':
                    Container.Position.Y++;
                    break;
                case 'd':
                    Container.Position.X++;
                    break;
            }
        }
    }
}
