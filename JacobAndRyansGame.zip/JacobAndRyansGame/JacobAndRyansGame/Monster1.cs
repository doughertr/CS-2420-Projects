﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JacobAndRyansGame
{
    class Monster
    {
        public Monster()
        {
            Position = new int[]{0,4};
        }
        public int[] Position { get; set; }
        public void MoveMonster(int[] targetLocation)
        {

        }
    }
}
