﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HW_5
{
    class BinarySearchTree<T> where T : IComparable<T>
    {
        IComparer<T> comparer;
        Node<T> runnerNode;
        int counter;
        public BinarySearchTree(IComparer<T> comparer = null)
        {
            rootNode = null;
            runnerNode = null;
            this.comparer = comparer;
            counter = 0;
        }

        public Node<T> rootNode { get; set; }
        public void AddItem(T item) 
        {
            Node<T> addedNode = new Node<T> { Value = item , leftChild = null, rightChild = null};

            if (rootNode == null)
            {
                rootNode = addedNode;
                runnerNode = rootNode;
            }
            else
            {
                runnerNode = rootNode;
                while (true)
                {
                    if (comparer != null)
                    {
                        if (comparer.Compare(item, runnerNode.Value) < 0)//item is less than Value
                        {
                            if (runnerNode.leftChild != null)
                                runnerNode = runnerNode.leftChild;
                            else 
                            {
                                runnerNode.leftChild = addedNode;
                                break;
                            }
                        }
                        else //item is greater than or equal to value 
                        {
                            if (runnerNode.rightChild != null)
                                runnerNode = runnerNode.rightChild;
                            else
                            {
                                runnerNode.rightChild = addedNode;
                                break;
                            }
                        }

                    }
                    else
                    {
                        if (item.CompareTo(runnerNode.Value) < 0) //item is less than Value
                        {
                            if (runnerNode.leftChild != null)
                                runnerNode = runnerNode.leftChild;
                            else
                            {
                                runnerNode.leftChild = addedNode;
                                break;
                            }
                        }
                        else //item is greater than or equal to Value 
                        {
                            if (runnerNode.rightChild != null)
                                runnerNode = runnerNode.rightChild;
                            else
                            {
                                runnerNode.rightChild = addedNode;
                                break;
                            }
                        }

                    }
                }
            }
            counter++;
        }
        public bool Contains(T item)
        {
            runnerNode = rootNode;
            while (runnerNode != null)
            {
                if (comparer != null)
                {
                    if (comparer.Compare(item, runnerNode.Value) < 0)
                    {
                        runnerNode = runnerNode.leftChild;
                    }
                    else if (comparer.Compare(item, runnerNode.Value) > 0)
                    {
                        runnerNode = runnerNode.rightChild;
                    }
                    else{
                        return true;
                    }
                }
                else
                {
                    if(item.CompareTo(runnerNode.Value) < 0)
                    {
                        runnerNode = runnerNode.leftChild;
                    }
                    else if (item.CompareTo(runnerNode.Value) > 0)
                    {
                        runnerNode = runnerNode.rightChild;
                    }
                    else
                    {
                        return true;
                    }

                }
            }
            return false;
        }

        public IEnumerator<T> TraversePre() //root, left, then right
        {
            return rootNode.TraversePre();
        }
        public IEnumerator<T> TraverseIn() //left, root, right
        {
            return rootNode.TraverseIn();
        }
        public IEnumerator<T> TraversePost() //left, right, root
        {
            return rootNode.TraversePost();
        }
    }
}
